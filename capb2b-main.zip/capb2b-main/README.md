# Back to basics with SAP CAP

See the [Back to basics playlist of live stream replays from the Hands-on SAP Dev show](https://www.youtube.com/playlist?list=PL6RpkC85SLQBHPdfHQ0Ry2TMdsT-muECx).

🚨 If you want to clone this repo and use it in VS Code as we do on the series, make sure you have the [Dev Containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers) extension installed in VS Code first. 
